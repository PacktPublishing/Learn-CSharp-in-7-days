# Day 3: What�s new in C#7.0/7.1 #

## Description ##

C# 7 would be changing the game with plenty of new features to the table. Some of these features like Tuples are extension of already available concept while others are entirely new.

## How to start? ##
Follow these steps:

* Open Visual Studio 2017 update 3 or later
* File -> Open [ctrl + shift + O]
* Go to [Day03](/Day03/Source%20code/Day03) click on solution and then click open	
* Click on Run or press F5
* Select appropriate option from the screen and run the code

## What we covered? ##

1. Odd Even from a Single Number.
2. Odd Even within a Range.
3. Odd Even from a Series.
4. Assignment.
5. Implicit Cast.
6. Comparison.
7. Equals.
8. Default Expression (C# 7.1).
9. Infer tuple names (C# 7.1).
