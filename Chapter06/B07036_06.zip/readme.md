# Day 6: Deep Dive with Advanced Concepts #

## Description ##

With the help of a real-world example, will cover more advanced topics of C#. This would build upon the previously discussed concepts like Generics, Collection and then take them forward by utilizing them together. Reader would learn about how to leverage the Preprocessor directives and not be intimidated by it. User would be introduced to the LINQ concept, starting from the basics and then taking it to the advanced level. Synchronous and Asynchronous programming will be explained.

## How to start? ##
Follow these steps:

* Open Visual Studio 2017 update 3 or later
* File -> Open [ctrl + shift + O]
* Go to [Day06](/Day06/source%20code/Day06) click on solution and then click open	
* Click on Run or press F5
* Select appropriate option from the screen and run the code

## What we covered? ##

1. Person List.
2. NonGeneric List With Author Name and Age.
3. Implement Value TypeGeneric Class.
4. Implement Reference Type GenericClass.
5. Implement Default Constructor Generic Class.
6. Implement Interface Constraint.
7. Test Custom Attribute.
8. Test Preprocessor Directive.
9. Test Linq.
10. Test Unsafe Swap.
11. BitArray vs. BoolArray performance test.