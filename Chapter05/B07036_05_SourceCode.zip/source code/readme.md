# Day 5: Reflection and Unsafe Code #

## Description ##

Introducing the readers to the event system available in C#. The world of events and delegates would be explored. Advance concepts like Anonymous Methods, Preprocessor directives and unsafe code would be covered. Concept of generics would be briefly touched upon.

## How to start? ##
Follow these steps:

* Open Visual Studio 2017 update 3 or later
* File -> Open [ctrl + shift + O]
* Go to [Day05](/Day05/source%20code/Day05) click on solution and then click open	
* Click on Run or press F5
* Select appropriate option from the screen and run the code

## What we covered? ##

1. Find Odd Even without reflection.
2. Find Odd Even using reflection.
3. Showing power of System.Type class - use typeof.
4. Showing power of System.Type class - use GetType().
5. Complete information using System.Reflection.Extensins class.
6. Delegates, Events Example.
7. ArrayList Example.
8. HashTable Example.
9. SortedList Example.
10. Stack Example.
11. Queue Example.