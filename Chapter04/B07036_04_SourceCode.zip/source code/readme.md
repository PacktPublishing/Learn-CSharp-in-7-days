# Day 4: �Discussing C# Class Members #

## Description ##

Fundamentals of C# methods and properties will be explained. The collection system discussed in the last chapter would be taken to the next level by introducing indexers. The string manipulation discussed earlier would be extended through RegEx and explain why it is powerful. File management would be covered along with some medium level file system observer.

## How to start? ##
Follow these steps:

* Open Visual Studio 2017 update 3 or later
* File -> Open [ctrl + shift + O]
* Go to [Day04](/Day04/source%20code/Day04) click on solution and then click open	
* Click on Run or press F5
* Select appropriate option from the screen and run the code

## What we covered? ##

1. Call String CalculatorUpdated.
2. Exception Example.
3. File Input Output Operation.
4. Regular Expression Example.
5. Indexer Example.